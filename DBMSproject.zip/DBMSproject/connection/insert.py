import mysql.connector
from mysql.connector import Error
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Database configuration
host = "Local instance MySQL80"
user = "LAPTOP-FF1B4JUJ"
password = "12210585"
database = "myproject"

@app.route('/')
def index():
    return render_template('searchbyname.html')

@app.route('/search', methods=['GET'])
def search():
    try:
        connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )

        search_term = request.args.get('q', default="", type=str)

        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)

            query = "SELECT * FROM ConstructionSupply WHERE ProductName LIKE %s"
            search_param = f"%{search_term}%"

            cursor.execute(query, (search_param,))
            results = cursor.fetchall()

            cursor.close()
            connection.close()

            return jsonify(results)
        else:
            return jsonify({"error": "Database connection failed."})
    except Error as e:
        print("Error:", e)
        return jsonify({"error": "An error occurred."})

if __name__ == '__main__':
    app.run(debug=True)
