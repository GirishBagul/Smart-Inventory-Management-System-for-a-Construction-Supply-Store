<?php
// Database configuration
$servername = "Local instance MySQL80";
$username = "LAPTOP-FF1B4JUJ";
$password = "12210585";
$dbname = "myproject";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchTerm = "";
$results = [];

// Process the search query
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM ConstructionSupply WHERE ProductName LIKE ?";
    $stmt = $conn->prepare($sql);

    // Bind parameter
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("s", $searchParam);

    // Execute query
    $stmt->execute();

    // Get results
    $result = $stmt->get_result();

    // Fetch rows
    while ($row = $result->fetch_assoc()) {
        $results[] = $row;
    }

    // Close statement
    $stmt->close();
}

// Close the connection
$conn->close();

// Display search results
if (!empty($results)) {
    foreach ($results as $row) {
        echo "<p>" . $row['ProductName'] . " - " . $row['Category'] . "</p>";
        // Add more columns you want to display
    }
} else {
    echo "<p>No results found.</p>";
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

?>
